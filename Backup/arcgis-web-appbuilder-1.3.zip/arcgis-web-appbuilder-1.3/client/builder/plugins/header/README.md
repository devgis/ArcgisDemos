* Published events:
  * closeAppConfigPage
