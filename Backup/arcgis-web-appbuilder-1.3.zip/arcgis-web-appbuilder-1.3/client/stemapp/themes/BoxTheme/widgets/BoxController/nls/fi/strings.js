﻿define(
   ({
    _widgetLabel: "Ruutusäädin"
  })
);
