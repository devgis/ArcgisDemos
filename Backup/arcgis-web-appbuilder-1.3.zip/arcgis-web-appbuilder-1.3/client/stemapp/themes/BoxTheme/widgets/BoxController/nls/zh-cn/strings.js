﻿define(
   ({
    _widgetLabel: "框控制器"
  })
);
