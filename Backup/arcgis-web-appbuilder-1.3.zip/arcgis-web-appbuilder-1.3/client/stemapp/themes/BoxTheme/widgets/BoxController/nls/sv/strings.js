﻿define(
   ({
    _widgetLabel: "Ruthanteraren"
  })
);
