﻿define(
   ({
    _widgetLabel: "Bokskontroller"
  })
);
