﻿define(
   ({
    _widgetLabel: "مُتحكم المربع"
  })
);
