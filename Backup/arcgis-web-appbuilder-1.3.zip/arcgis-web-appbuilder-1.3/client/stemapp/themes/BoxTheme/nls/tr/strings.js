﻿define(
   ({
    _themeLabel: "Kutu Teması",
    _layout_default: "Varsayılan Düzen",
    _layout_top: "En Üst Yerleşim"
  })
);