﻿define(
   ({
    _themeLabel: "Θέμα Box",
    _layout_default: "Προκαθορισμένη διάταξη",
    _layout_top: "Κορυφαία διάταξη"
  })
);