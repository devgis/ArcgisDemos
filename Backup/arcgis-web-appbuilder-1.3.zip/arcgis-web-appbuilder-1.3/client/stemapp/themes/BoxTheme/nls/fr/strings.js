﻿define(
   ({
    _themeLabel: "Thème encart",
    _layout_default: "Mise en page par défaut",
    _layout_top: "Mise en page supérieure"
  })
);