﻿define(
   ({
    _themeLabel: "Temă cutie",
    _layout_default: "Configuraţie implicită",
    _layout_top: "Configuraţie superioară"
  })
);