﻿define(
   ({
    _themeLabel: "佈告欄主題",
    _layout_default: "預設版面配置",
    _layout_right: "正確版面配置"
  })
);