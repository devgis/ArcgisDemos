﻿define(
   ({
    _themeLabel: "布告栏主题",
    _layout_default: "默认布局",
    _layout_right: "右侧布局"
  })
);