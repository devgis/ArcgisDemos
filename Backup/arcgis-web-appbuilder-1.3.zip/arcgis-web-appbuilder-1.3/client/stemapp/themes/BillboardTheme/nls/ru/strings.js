﻿define(
   ({
    _themeLabel: "Тема билборда",
    _layout_default: "Компоновка по умолчанию",
    _layout_right: "Компоновка по правому краю"
  })
);