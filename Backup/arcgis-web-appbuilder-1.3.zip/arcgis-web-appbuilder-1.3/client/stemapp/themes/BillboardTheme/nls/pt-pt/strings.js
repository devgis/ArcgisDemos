﻿define(
   ({
    _themeLabel: "Tema de Quadro de Aviso",
    _layout_default: "Layout Padrão",
    _layout_right: "Layout Direita"
  })
);