﻿define(
   ({
    _themeLabel: "ビルボード テーマ",
    _layout_default: "デフォルトのレイアウト",
    _layout_right: "右レイアウト"
  })
);