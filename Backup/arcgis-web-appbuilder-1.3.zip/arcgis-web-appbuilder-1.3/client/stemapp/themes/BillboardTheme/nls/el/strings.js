﻿define(
   ({
    _themeLabel: "Θέμα Πίνακας ανακοινώσεων",
    _layout_default: "Προκαθορισμένη διάταξη",
    _layout_right: "Διάταξη στα δεξιά"
  })
);