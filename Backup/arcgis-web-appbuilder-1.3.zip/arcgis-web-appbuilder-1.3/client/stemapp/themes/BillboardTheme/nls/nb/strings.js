﻿define(
   ({
    _themeLabel: "Reklametavletema",
    _layout_default: "Standard oppsett",
    _layout_right: "Høyreoppsett"
  })
);