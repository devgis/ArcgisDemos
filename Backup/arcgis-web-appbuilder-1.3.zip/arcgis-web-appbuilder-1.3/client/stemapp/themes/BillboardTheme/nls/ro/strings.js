﻿define(
   ({
    _themeLabel: "Temă panou publicitar",
    _layout_default: "Configuraţie implicită",
    _layout_right: "Aspect corect"
  })
);